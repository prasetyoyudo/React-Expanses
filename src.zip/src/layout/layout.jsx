import { useEffect, useState } from "react";
import { getListExpanses } from "../actions/expanses";
import { useDispatch, useSelector } from "react-redux";
import { AddExpanses } from "./add-expanses/add-expanses";
import "./layout.css";
import moment from "moment";
import "moment/locale/id";

export function Layout() {
  const { getListExpansesRes, getListExpansesLoading, getListExpansesError } =
    useSelector((state) => state.ExpansesReducer);
  const [showAddModal, setShowAddModal] = useState(false);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getListExpanses());
  }, [dispatch]);

  return (
    <div className="body-layout">
      <h4 className="mx-auto text-center text-2xl font-bold mb-6 pt-8">
        List Pengeluaran
      </h4>
      <div className="text-center mx-auto">
        <button
          className="rounded-full w-fit p-8 mx-auto text-center add-btn mb-4"
          onClick={() => setShowAddModal(true)}
        >
          Tambah pengeluaran
        </button>
        {showAddModal && (
          <div className="add-modal-expanses">
            <AddExpanses />
          </div>
        )}
      </div>
      <div className="grid grid-cols-3 gap-4 mx-8">
        {getListExpansesRes ? (
          getListExpansesRes.map((expand) => {
            return (
              <div key={expand.id}>
                <div className="block p-6 max-w-sm bg-white rounded-lg border border-gray-200 shadow-md hover:bg-gray-100 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                  <h5 className="mb-2 text-lg font-medium tracking-tight text-gray-900 dark:text-white">
                    {moment(expand.tanggal).locale("id").format("DD MMMM YYYY")}
                  </h5>
                  {expand.summary.map((dataSummary) => {
                      <div className="flex" key={dataSummary.jam}>
                        <p>{dataSummary.jam}</p>
                      </div>;
                  })}
                  {/* <div className="flex justify-between">
                    <div className="flex">
                      <p className="font-normal text-gray-700 dark:text-gray-400">
                        {moment(expand.jam).format('LT')}
                      </p>
                      <p className="font-normal text-gray-700 dark:text-gray-400 ml-2 block">
                        {expand.nama}
                      </p>
                    </div>
                    <p className="font-normal text-gray-700 dark:text-gray-400">
                      {'Rp ' + expand.pengeluaran.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')}
                    </p>
                  </div> */}
                </div>
              </div>
            );
          })
        ) : getListExpansesLoading ? (
          <p>Loading ...</p>
        ) : (
          <p>{getListExpansesError ? getListExpansesError : "Data Kosong"}</p>
        )}
      </div>
    </div>
  );
}
