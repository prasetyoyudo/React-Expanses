import { combineReducers } from "redux";
import ExpansesReducer from "./expanses";

export default combineReducers({
  ExpansesReducer
})